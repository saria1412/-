package com.sarf.qasioun.prayer;

/** Independent 4x1 home-screen widget provider. Shares live update logic with 4x2 widget. */
public final class WidgetCompactProvider extends WidgetProvider { }
