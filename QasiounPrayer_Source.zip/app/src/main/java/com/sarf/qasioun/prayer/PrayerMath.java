package com.sarf.qasioun.prayer;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

/** Date/time calculations isolated from Android so tests can run with the JDK. */
public final class PrayerMath {
    private PrayerMath() {}

    public static long epochMillis(LocalDate day, String hhmm, String ianaZone) {
        String clock = hhmm.substring(0, 5);
        LocalTime localTime = LocalTime.parse(clock);
        return ZonedDateTime.of(day, localTime, ZoneId.of(ianaZone)).toInstant().toEpochMilli();
    }

    public static long remainingMillis(long nowMs, long nextMs) { return Math.max(0L, nextMs - nowMs); }

    public static boolean isFresh(long savedEpochMillis, long nowMillis, int hours) {
        return savedEpochMillis > 0 && savedEpochMillis <= nowMillis + 5 * 60_000L
                && nowMillis - savedEpochMillis <= hours * 3_600_000L;
    }

    public static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        double radius = 6371.009;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = p2 - p1, dl = Math.toRadians(lon2 - lon1);
        double a = Math.pow(Math.sin(dp / 2.0), 2) + Math.cos(p1) * Math.cos(p2) * Math.pow(Math.sin(dl / 2.0), 2);
        return radius * 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
    }
}
