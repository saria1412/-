package com.sarf.qasioun.prayer;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

public class WidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.sarf.qasioun.prayer.REFRESH";
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        renderAll(context);
        RefreshJobService.start(context);
    }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            RefreshJobService.start(context);
            renderAll(context);
        }
    }
    public static void renderAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        PrayerEngine.Snapshot snapshot = PrayerEngine.snapshot(context);
        updateGroup(context, manager, snapshot, WidgetProvider.class, R.layout.prayer_widget);
        updateGroup(context, manager, snapshot, WidgetCompactProvider.class, R.layout.prayer_widget_compact);
    }
    private static void updateGroup(Context context, AppWidgetManager manager,
            PrayerEngine.Snapshot snapshot, Class<?> providerClass, int layoutId) {
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, providerClass));
        if (ids == null || ids.length == 0) return;
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(context.getPackageName(), layoutId);
            Intent launch = new Intent(context, MainActivity.class);
            PendingIntent open = PendingIntent.getActivity(context, 10, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.widget_root, open);
            Intent ref = new Intent(context, WidgetProvider.class).setAction(ACTION_REFRESH);
            PendingIntent refresh = PendingIntent.getBroadcast(context, 11, ref,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.widget_refresh, refresh);
            rv.setTextViewText(R.id.widget_city, PrayerStore.city(context));
            if (snapshot != null) {
                rv.setTextViewText(R.id.widget_hijri, snapshot.hijri());
                if (snapshot.next() != null) {
                    rv.setTextViewText(R.id.widget_next, "الأذان القادم: " + snapshot.next().name());
                    rv.setTextViewText(R.id.widget_next_time, PrayerEngine.format(snapshot.next(), snapshot.tz()));
                    long remaining = PrayerMath.remainingMillis(System.currentTimeMillis(), snapshot.next().epochMs());
                    rv.setViewVisibility(R.id.widget_countdown, View.VISIBLE);
                    rv.setChronometer(R.id.widget_countdown, SystemClock.elapsedRealtime() + remaining, null, true);
                    rv.setChronometerCountDown(R.id.widget_countdown, true);
                } else {
                    rv.setTextViewText(R.id.widget_next, "جاري الانتقال إلى يوم جديد");
                    rv.setTextViewText(R.id.widget_next_time, "سيتم التحديث قريبًا");
                    rv.setChronometer(R.id.widget_countdown, SystemClock.elapsedRealtime(), null, false);
                    rv.setViewVisibility(R.id.widget_countdown, View.GONE);
                }
                int[] idViews = {R.id.t_fajr,R.id.t_sunrise,R.id.t_dhuhr,R.id.t_asr,R.id.t_maghrib,R.id.t_isha};
                rv.setTextViewText(R.id.t_sunrise, "الشروق\n" + PrayerEngine.formatShort(snapshot.sunrise(), snapshot.tz()));
                for (int i=0; i<snapshot.today().size(); i++) {
                    PrayerEngine.Event e = snapshot.today().get(i);
                    int index=i==0?0:i+1;
                    rv.setTextViewText(idViews[index], e.name() + "\n" + PrayerEngine.formatShort(e, snapshot.tz()));
                }
                if (!PrayerMath.isFresh(snapshot.updatedAt(), System.currentTimeMillis(), 8))
                    rv.setTextViewText(R.id.widget_hijri, snapshot.hijri() + " · محفوظة");
            } else {
                rv.setTextViewText(R.id.widget_hijri, "تقويم أم القرى");
                rv.setTextViewText(R.id.widget_next, "في انتظار المواقيت");
                rv.setTextViewText(R.id.widget_next_time, "اضغط لتفعيل الموقع");
                rv.setViewVisibility(R.id.widget_countdown, View.GONE);
                int[] idViews = {R.id.t_fajr,R.id.t_sunrise,R.id.t_dhuhr,R.id.t_asr,R.id.t_maghrib,R.id.t_isha};
                for (int i=0; i<idViews.length; i++) rv.setTextViewText(idViews[i], PrayerStore.DISPLAY_NAMES[i] + "\n--:--");

            }
            manager.updateAppWidget(id, rv);
        }
    }
}
