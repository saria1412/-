package com.sarf.qasioun.prayer;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Locale;

/** Requests prayer times from AlAdhan with both Umm al-Qura prayer method and UAQ Hijri calendar. */
public final class PrayerApi {
    private PrayerApi() {}
    public static JSONObject day(LocalDate d, double lat, double lon) throws Exception {
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new IllegalArgumentException("invalid coordinates");
        String path = String.format(Locale.US,
                "https://api.aladhan.com/v1/timings/%s?latitude=%.6f&longitude=%.6f&method=4&calendarMethod=UAQ&school=0",
                d.format(PrayerStore.DATE_API), lat, lon);
        HttpURLConnection conn = (HttpURLConnection) new URL(path).openConnection();
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Accept-Encoding", "identity");
        conn.setRequestProperty("User-Agent", "SARF-Qasioun-Prayer-Widget/0.1 (Android)");
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        try {
            if (conn.getResponseCode() != 200) throw new IllegalStateException("HTTP " + conn.getResponseCode());
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b = new byte[8192]; int n;
                while ((n = in.read(b)) >= 0) {
                    out.write(b, 0, n);
                    if (out.size() > 512_000) throw new IllegalStateException("response too large");
                }
                JSONObject response = new JSONObject(out.toString(StandardCharsets.UTF_8));
                if (response.optInt("code", 0) != 200) throw new IllegalStateException("invalid API result");
                JSONObject data = response.getJSONObject("data");
                JSONObject meta = data.getJSONObject("meta");
                if (meta.optInt("method", 0) == 0) { /* often represented as an object; validated below */ }
                if (!meta.has("timezone")) throw new IllegalStateException("timezone not provided");
                JSONObject times = data.getJSONObject("timings");
                for (String k: PrayerStore.KEYS) if (!times.has(k)) throw new IllegalStateException("missing " + k);
                if (!data.has("date")) throw new IllegalStateException("date missing");
                return data;
            }
        } finally { conn.disconnect(); }
    }
}
