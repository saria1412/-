package com.sarf.qasioun.prayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

/** The user-facing Umm al-Qura prayer screen; sunrise is shown but never scheduled as an adhan. */
public class MainActivity extends Activity {
    private static final int GPS_REQUEST = 203;
    private static final int NOTIFICATION_REQUEST = 204;
    private static final int AUDIO_PICKER = 205;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView[] timeValues = new TextView[6];
    private int gold, ivory, muted, green, cardGreen;
    private Typeface kufiRegular,kufiMedium,kufiBold;
    private TextView city, status, next, countdown, hijri, permissions;
    private Switch adhanToggle;
    private final Runnable tick = new Runnable() {
        @Override public void run() { redraw(); handler.postDelayed(this, 10000L); }
    };

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(7, 40, 33));
        getWindow().setNavigationBarColor(Color.rgb(7, 40, 33));
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        gold = getColor(R.color.gold); ivory = getColor(R.color.ivory);
        muted = getColor(R.color.muted); green = getColor(R.color.damascus_green);
        cardGreen = getColor(R.color.green2);
        kufiRegular = getResources().getFont(R.font.noto_kufi_arabic_regular);
        kufiMedium = getResources().getFont(R.font.noto_kufi_arabic_medium);
        kufiBold = getResources().getFont(R.font.noto_kufi_arabic_bold);
        AlarmReceiver.ensureChannels(this);
        createScreen();
        WidgetProvider.renderAll(this);
        RefreshJobService.start(this);
    }
    @Override protected void onResume() {
        super.onResume(); handler.removeCallbacks(tick); handler.post(tick);
        AlarmReceiver.scheduleAll(this);
    }
    @Override protected void onPause() { handler.removeCallbacks(tick); super.onPause(); }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private TextView text(String value, float size, int color, boolean strong) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size);
        t.setIncludeFontPadding(false); t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTypeface(strong ? kufiBold : kufiRegular);
        t.setLineSpacing(dp(1), 1.02f);
        return t;
    }
    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    private LinearLayout card(LinearLayout parent, int marginTop) {
        LinearLayout l = column();
        l.setPadding(dp(17), dp(17), dp(17), dp(17));
        l.setBackground(shape(cardGreen, Color.argb(85, 212, 183, 117), 19));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(marginTop); parent.addView(l, lp); return l;
    }
    private Button button(String label, boolean primary, Runnable action) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(label); b.setTextSize(14);
        b.setTypeface(kufiMedium);
        b.setTextColor(primary ? green : gold);
        b.setBackgroundTintList(null);
        b.setBackground(shape(primary ? gold : cardGreen, primary ? Color.TRANSPARENT : Color.argb(130,212,183,117), 12));
        b.setMinHeight(dp(48));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void addButton(LinearLayout parent, String title, boolean primary, Runnable action) {
        Button b = button(title, primary, action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10); parent.addView(b, lp);
    }
    private void separator(LinearLayout parent) {
        View v = new View(this); v.setBackgroundColor(Color.argb(35, 255, 255, 255));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.topMargin = dp(9); lp.bottomMargin = dp(9); parent.addView(v, lp);
    }
    private void prayerRow(LinearLayout parent, String name, int index, boolean sun) {
        LinearLayout r = row();
        TextView label = text((sun ? "☀  " : "") + name, 15, sun ? gold : ivory, false);
        r.addView(label, new LinearLayout.LayoutParams(0, dp(29), 1));
        TextView value = text("--:--", 15, sun ? gold : ivory, true);
        value.setTextDirection(View.TEXT_DIRECTION_LTR);
        value.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        value.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        r.addView(value, new LinearLayout.LayoutParams(dp(102), dp(29)));
        timeValues[index] = value;
        parent.addView(r, new LinearLayout.LayoutParams(-1, dp(33)));
        if (index != 5) separator(parent);
    }
    private void createScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        scroll.setBackgroundColor(green);
        LinearLayout body = column();
        body.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(body);
        LinearLayout header = row();
        ImageView mosque = new ImageView(this);
        mosque.setImageResource(R.mipmap.ic_launcher);
        mosque.setContentDescription("رمز الجامع الأموي بدمشق");
        mosque.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(63),dp(63));
        iconParams.leftMargin = dp(12); header.addView(mosque, iconParams);
        LinearLayout headings = column();
        headings.addView(text("مواقيت الصلاة", 23, gold, true));
        LinearLayout brandRow=row();
        brandRow.addView(text("تقويم أم القرى  ·  ", 11, muted, false));
        brandRow.addView(text("★ ★ ★", 10, getColor(R.color.syrian_red), true));
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(-1,-2);
        brandLp.topMargin = dp(4); headings.addView(brandRow,brandLp);
        header.addView(headings, new LinearLayout.LayoutParams(0,-2,1)); body.addView(header);
        city = text("جارٍ تحديد المدينة…", 14, ivory, true);
        LinearLayout cityRow = row();
        TextView pin = text("◉", 19, gold, true);
        LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(dp(25), dp(34));
        cityRow.addView(pin, pinLp);
        cityRow.addView(city, new LinearLayout.LayoutParams(0, dp(34), 1));
        cityRow.setPadding(dp(13), dp(3), dp(13), dp(3));
        cityRow.setBackground(shape(Color.rgb(13, 67, 56), Color.TRANSPARENT, 14));
        LinearLayout.LayoutParams cityLp = new LinearLayout.LayoutParams(-1,-2);
        cityLp.topMargin = dp(12); body.addView(cityRow, cityLp);

        LinearLayout upcoming = card(body, 13);
        upcoming.addView(text("الصلاة القادمة", 13, muted, false));
        next = text("انتظار المواقيت", 21, ivory, true);
        LinearLayout.LayoutParams nxtLp = new LinearLayout.LayoutParams(-1,-2); nxtLp.topMargin=dp(8);
        upcoming.addView(next, nxtLp);
        countdown = text("--:--:--", 34, gold, true);
        countdown.setTextDirection(View.TEXT_DIRECTION_LTR);
        countdown.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(-1,-2);
        countLp.topMargin = dp(7); upcoming.addView(countdown, countLp);
        upcoming.addView(text("الوقت المتبقي حتى الأذان", 12, muted, false));

        LinearLayout timings = card(body, 12);
        LinearLayout titleRow = row();
        TextView title = text("مواقيت اليوم", 18, gold, true);
        titleRow.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        hijri = text("", 11, muted, false);
        hijri.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        titleRow.addView(hijri,new LinearLayout.LayoutParams(-2,-2));
        timings.addView(titleRow);
        separator(timings);
        String[] labels = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
        for (int i = 0; i < labels.length; i++) prayerRow(timings, labels[i], i, i == 1);
        status = text("المواقيت لم تُحدّث بعد", 12, muted, false);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1,-2);
        statusLp.topMargin=dp(14); timings.addView(status,statusLp);

        addButton(body,"تحديث الموقع ومواقيت الصلاة",true,this::requestLocation);
        addButton(body,"اتجاه القبلة والبوصلة",false,() -> startActivity(new Intent(this,QiblaActivity.class)));
        TextView help = text("تحديث تلقائي دوري عند توفر الشبكة. يستمر العد التنازلي بآخر المواقيت المخزنة.",12,muted,false);
        LinearLayout.LayoutParams helpLp = new LinearLayout.LayoutParams(-1,-2);
        helpLp.topMargin=dp(10); body.addView(help,helpLp);

        LinearLayout settings = card(body, 17);
        settings.addView(text("الأذان والتنبيهات",18,gold,true));
        adhanToggle = new Switch(this);
        adhanToggle.setText("تشغيل الأذان عند دخول الوقت");
        adhanToggle.setTextColor(ivory); adhanToggle.setTextSize(14); adhanToggle.setTypeface(kufiMedium);
        adhanToggle.setChecked(PrayerStore.adhanEnabled(this));
        adhanToggle.setOnCheckedChangeListener((compound,on)-> {
            PrayerStore.p(this).edit().putBoolean("adhan_enabled",on).apply();
            AlarmReceiver.scheduleAll(this);
            if (!on) stopService(new Intent(this,AdhanService.class));
            if (on) { requestNotification();requestExactAlarmIfNeeded(); }
            redraw();
        });
        settings.addView(adhanToggle);
        addButton(settings,"السماح بإشعارات الأذان",false,this::requestNotification);
        addButton(settings,"السماح بالمنبهات الدقيقة",false,this::requestExactAlarmIfNeeded);
        addButton(settings,"تجربة صوت الأذان",false,()-> {
            if (PrayerStore.adhanEnabled(this)) {
                try { startForegroundService(new Intent(this,AdhanService.class)
                        .setAction(AdhanService.START).putExtra("prayer","تجريبي")); }
                catch (Exception ex) { Toast.makeText(this,"تعذر تشغيل الصوت؛ راجع أذونات النظام",Toast.LENGTH_LONG).show(); }
            } else Toast.makeText(this,"فعّل الأذان أولًا",Toast.LENGTH_LONG).show();
        });
        addButton(settings,"اختيار صوت الأذان من الهاتف",false,()-> {
            Intent choose = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*");
            choose.addCategory(Intent.CATEGORY_OPENABLE);
            choose.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(choose,AUDIO_PICKER);
        });
        addButton(settings,"استعادة صوت الأذان الأصلي",false,()-> {
            PrayerStore.p(this).edit().remove("custom_audio").apply();
            Toast.makeText(this,"تم استعادة الصوت الأصلي",Toast.LENGTH_SHORT).show();
        });
        settings.addView(text("عند السفر يمكن السماح بالموقع طوال الوقت لتحديث المدينة أثناء عمل التطبيق بالخلفية.",12,muted,false));
        addButton(settings,"إعدادات الوصول للموقع طوال الوقت",false,()-> {
            Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            d.setData(Uri.parse("package:"+getPackageName())); startActivity(d);
        });
        permissions = text("",11,muted,false);
        LinearLayout.LayoutParams permissionsLp = new LinearLayout.LayoutParams(-1,-2);
        permissionsLp.topMargin=dp(12); settings.addView(permissions,permissionsLp);
        TextView source = text("الحساب: جامعة أم القرى (4) · الشروق للعرض فقط ولا يُؤذَّن عنده. المكان يُستخدم لجلب المواقيت وتحديد المدينة. قد تختلف بعض الدقائق عن التقويم المحلي الرسمي.",11,muted,false);
        LinearLayout.LayoutParams sourceLp = new LinearLayout.LayoutParams(-1,-2);
        sourceLp.topMargin=dp(15); body.addView(source,sourceLp);
        setContentView(scroll);
    }

    private void redraw() {
        if (status == null) return;
        city.setText(PrayerStore.city(this));
        PrayerEngine.Snapshot sn = PrayerEngine.snapshot(this);
        if (sn == null) {
            next.setText("في انتظار مواقيت اليوم"); countdown.setText("--:--:--");
            for (TextView t:timeValues) t.setText("--:--");
            hijri.setText("تقويم أم القرى");
            status.setText("حدّث الموقع للبدء. " + PrayerStore.lastError(this));
        } else {
            PrayerEngine.Event e=sn.next();
            next.setText(e==null ? "جاري تحميل مواقيت الغد" : "أذان "+e.name());
            long remain=e==null ? 0 : PrayerMath.remainingMillis(System.currentTimeMillis(),e.epochMs())/1000;
            countdown.setText(e==null ? "--:--:--" : String.format(Locale.US,"%02d:%02d:%02d",remain/3600,remain%3600/60,remain%60));
            String[] formatted=new String[6];
            for (int i=0; i<sn.today().size();i++) {
                int to=i==0 ? 0 : i+1;
                formatted[to]=PrayerEngine.format(sn.today().get(i),sn.tz());
            }
            formatted[1]=PrayerEngine.formatSunrise(sn.sunrise());
            for (int i=0;i<6;i++)timeValues[i].setText(formatted[i]==null?"--:--":formatted[i]);
            hijri.setText(sn.hijri());
            String time=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,new Locale("ar","SA"))
                    .format(new Date(sn.updatedAt()));
            status.setText("آخر تحديث: "+time + (PrayerMath.isFresh(sn.updatedAt(),System.currentTimeMillis(),8)?" · محدث":" · بيانات محفوظة"));
        }
        boolean gps=hasLocationAccess();
        AlarmManager manager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        boolean exact=Build.VERSION.SDK_INT<31 || (manager!=null && manager.canScheduleExactAlarms());
        boolean notif=Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
        boolean back=checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED;
        permissions.setText("الأذونات: الموقع "+(gps?"✓":"✗")+" · الخلفية "+(back?"✓":"✗")+
                " · الإشعارات "+(notif?"✓":"✗")+" · المنبهات "+(exact?"✓":"✗"));
    }
    private boolean hasLocationAccess() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestLocation() {
        if (!hasLocationAccess()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},GPS_REQUEST);
            return;
        }
        LocationManager loc=(LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if (loc==null){Toast.makeText(this,"تعذر الوصول لخدمات الموقع",Toast.LENGTH_LONG).show();return;}
        status.setText("جارٍ تحديد الموقع والمدينة…");
        getCurrentLocation(loc,LocationManager.NETWORK_PROVIDER,false);
    }
    private void getCurrentLocation(LocationManager lm,String provider,boolean triedGps){
        try {
            if(!lm.isProviderEnabled(provider)){
                if(!triedGps)getCurrentLocation(lm,LocationManager.GPS_PROVIDER,true);
                else Toast.makeText(this,"فعّل GPS ثم أعد المحاولة",Toast.LENGTH_LONG).show();
                return;
            }
            lm.getCurrentLocation(provider,null,getMainExecutor(),l->{
                if(l==null && !triedGps){getCurrentLocation(lm,LocationManager.GPS_PROVIDER,true);return;}
                if(l==null){Toast.makeText(this,"تعذر تحديد موقع جديد",Toast.LENGTH_LONG).show();redraw();return;}
                PrayerStore.saveLocation(this,l);
                PrayerStore.p(this).edit().putBoolean("force_refresh",true).apply();
                RefreshJobService.start(this);
                city.setText("جارٍ تحديد اسم المدينة…");
                status.setText("جارٍ تحديث مواقيت أم القرى…");
                new Thread(()->CityResolver.resolve(this),"QasiounCityLookup").start();
            });
        } catch(SecurityException e){Toast.makeText(this,"يجب السماح باستخدام الموقع",Toast.LENGTH_LONG).show();}
        catch(Exception e){Toast.makeText(this,"تعذر الحصول على الموقع",Toast.LENGTH_LONG).show();}
    }
    private void requestNotification(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST);
        else Toast.makeText(this,"إذن الإشعارات متاح",Toast.LENGTH_SHORT).show();
    }
    private void requestExactAlarmIfNeeded(){
        AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        if(Build.VERSION.SDK_INT>=31 && am!=null && !am.canScheduleExactAlarms()){
            Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            i.setData(Uri.parse("package:"+getPackageName()));
            try{startActivity(i);}catch(Exception e){Toast.makeText(this,"افتح أذونات المنبهات الدقيقة",Toast.LENGTH_LONG).show();}
        }
    }
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] result){
        super.onRequestPermissionsResult(req,perms,result);
        if(req==GPS_REQUEST && hasLocationAccess())requestLocation();
        else if(req==GPS_REQUEST)Toast.makeText(this,"يحتاج التطبيق إذن الموقع لحساب مواقيتك",Toast.LENGTH_LONG).show();
        redraw();
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=AUDIO_PICKER||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri audio=data.getData();
        try{
            getContentResolver().takePersistableUriPermission(audio,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            PrayerStore.p(this).edit().putString("custom_audio",audio.toString()).apply();
            Toast.makeText(this,"تم حفظ صوت الأذان",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"تعذر حفظ الملف الصوتي",Toast.LENGTH_LONG).show();}
    }
}
