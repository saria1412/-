package com.sarf.qasioun.prayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GPS_REQUEST = 203;
    private static final int NOTIFICATION_REQUEST = 204;
    private static final int AUDIO_PICKER = 205;
    private int gold, ivory, muted, green;
    private TextView status, next, countdown, times, permissions;
    private Switch adhanToggle;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { redraw(); handler.postDelayed(this, 10_000L); }
    };
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        gold = getColor(R.color.gold); ivory = getColor(R.color.ivory);
        muted = getColor(R.color.muted); green = getColor(R.color.damascus_green);
        AlarmReceiver.ensureChannels(this);
        createScreen();
        WidgetProvider.renderAll(this);
        RefreshJobService.start(this);
    }
    @Override protected void onResume() {
        super.onResume(); handler.removeCallbacks(tick); handler.post(tick);
        AlarmReceiver.scheduleAll(this);
    }
    @Override protected void onPause() { handler.removeCallbacks(tick); super.onPause(); }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        v.setGravity(Gravity.RIGHT); v.setPadding(0, dp(5), 0, dp(5));
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private Button button(String title, Runnable cb) {
        Button btn = new Button(this);
        btn.setText(title); btn.setTextColor(green); btn.setBackgroundTintList(ColorStateList.valueOf(gold));
        btn.setOnClickListener(v -> cb.run()); return btn;
    }
    private void createScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(20), dp(26), dp(20), dp(28));
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); body.setBackgroundColor(green);
        scroll.addView(body);
        TextView title = text("☪ قاسيون | الصلاة والأذان", 24, gold, true); body.addView(title);
        body.addView(text("مواقيت أم القرى حسب موقعك • ألوان الثيم الدمشقي", 13, muted, false));
        TextView border = text("────────────────────", 17, gold, false); body.addView(border);
        next = text("الصلاة القادمة", 22, ivory, true); body.addView(next);
        countdown = text("--:--:--", 31, gold, true); body.addView(countdown);
        times = text("الفجر   --:--\nالظهر   --:--\nالعصر   --:--\nالمغرب   --:--\nالعشاء   --:--", 17, ivory, false);
        times.setLineSpacing(dp(6), 1.1f); body.addView(times);
        status = text("انتظار صلاحية الموقع واتصال الإنترنت", 13, muted, false); body.addView(status);
        body.addView(button("📍 تحديد الموقع وتحديث المواقيت الآن", this::requestLocation));
        body.addView(text("التحديث التلقائي: كل ساعة تقريبًا وعند تغير اليوم؛ والعد التنازلي يعمل حتى بدون إنترنت.", 12, muted, false));
        body.addView(text("التنبيهات والصوت", 18, gold, true));
        adhanToggle = new Switch(this);
        adhanToggle.setText("تشغيل الأذان عند دخول الوقت"); adhanToggle.setTextColor(ivory);
        adhanToggle.setTextSize(15); adhanToggle.setChecked(PrayerStore.adhanEnabled(this));
        adhanToggle.setOnCheckedChangeListener((cb, on) -> {
            PrayerStore.p(this).edit().putBoolean("adhan_enabled", on).apply();
            AlarmReceiver.scheduleAll(this);
            if (!on) stopService(new Intent(this, AdhanService.class));
            if (on) { requestNotification(); requestExactAlarmIfNeeded(); }
            redraw();
        });
        body.addView(adhanToggle);
        body.addView(button("🔔 السماح بإشعارات الأذان", this::requestNotification));
        body.addView(button("⏰ السماح بالمنبهات الدقيقة", this::requestExactAlarmIfNeeded));
        body.addView(button("▶ تجربة صوت الأذان الآن", () -> {
            if (PrayerStore.adhanEnabled(this)) startForegroundService(new Intent(this, AdhanService.class)
                    .setAction(AdhanService.START).putExtra("prayer", "تجريبي"));
            else Toast.makeText(this, "شغّل خيار الأذان أولًا", Toast.LENGTH_LONG).show();
        }));
        body.addView(button("🎵 اختيار ملف أذان من الهاتف (اختياري)", () -> {
            Intent choose = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*");
            choose.addCategory(Intent.CATEGORY_OPENABLE);
            choose.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(choose, AUDIO_PICKER);
        }));
        body.addView(button("استعادة صوت الأذان المرفق", () -> {
            PrayerStore.p(this).edit().remove("custom_audio").apply();
            Toast.makeText(this, "تم اختيار صوت الأذان المرفق", Toast.LENGTH_SHORT).show();
        }));
        body.addView(text("الموقع أثناء وجود التطبيق بالخلفية", 18, gold, true));
        body.addView(text("للتحديث التلقائي بعد السفر دون فتح التطبيق، اسمح للموقع 'طوال الوقت' من إعدادات التطبيق. لا يُرسَل موقعك إلا لخدمة حساب المواقيت.", 13, muted, false));
        body.addView(button("السماح بالموقع طوال الوقت (اختياري)", () -> {
            Intent detail = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            detail.setData(Uri.parse("package:" + getPackageName()));
            startActivity(detail);
        }));
        permissions = text("", 12, muted, false); body.addView(permissions);
        body.addView(text("المصدر: AlAdhan API | طريقة جامعة أم القرى بمكة (4) | التاريخ الهجري UAQ.\nقد تختلف الدقائق عن أوقات مسجد الحي أو الجهات الرسمية؛ تحقق من المواقيت عند الضرورة.", 12, muted, false));
        setContentView(scroll);
    }

    private void redraw() {
        if (status == null) return;
        PrayerEngine.Snapshot sn = PrayerEngine.snapshot(this);
        if (sn == null) {
            next.setText("مواقيت الصلاة"); countdown.setText("--:--:--");
            times.setText("افتح الموقع وحدّث مواقيت اليوم والغد");
            status.setText("لا توجد مواقيت صالحة لموقعك الحالي. " + PrayerStore.lastError(this));
        } else {
            PrayerEngine.Event e = sn.next();
            next.setText(e == null ? "جاري تحديث مواقيت الغد" : "الأذان القادم: " + e.name());
            long remain = e == null ? 0 : PrayerMath.remainingMillis(System.currentTimeMillis(), e.epochMs()) / 1000;
            countdown.setText(e == null ? "--:--:--" : String.format(Locale.US, "%02d:%02d:%02d", remain / 3600, remain % 3600 / 60, remain % 60));
            StringBuilder data = new StringBuilder();
            for (PrayerEngine.Event p : sn.today()) data.append(p.name()).append("     ").append(PrayerEngine.format(p, sn.tz())).append('\n');
            times.setText(data.toString());
            String time = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT, new Locale("ar", "SA"))
                    .format(new Date(sn.updatedAt()));
            String coords = String.format(Locale.US, "%.3f, %.3f", PrayerStore.lat(this), PrayerStore.lon(this));
            status.setText(sn.hijri() + " | الموقع: " + coords + "\nآخر تحديث: " + time + " | " +
                    (PrayerMath.isFresh(sn.updatedAt(), System.currentTimeMillis(), 8) ? "متصل" : "مواقيت مخزنة"));
        }
        boolean gps = hasLocationAccess();
        boolean exact = Build.VERSION.SDK_INT < 31 || ((AlarmManager)getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();
        boolean notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        boolean back = checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED;
        permissions.setText("الأذونات: الموقع " + (gps ? "✓" : "✗") + " · الخلفية " + (back ? "✓" : "✗") +
                " · الإشعارات " + (notif ? "✓" : "✗") + " · الأذان الدقيق " + (exact ? "✓" : "✗"));
    }
    private boolean hasLocationAccess() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestLocation() {
        if (!hasLocationAccess()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, GPS_REQUEST);
            return;
        }
        LocationManager loc = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if (loc == null) { Toast.makeText(this, "تعذر الوصول إلى خدمات الموقع", Toast.LENGTH_LONG).show(); return; }
        status.setText("جارٍ قراءة الموقع الجغرافي الحالي...");
        getCurrentLocation(loc, LocationManager.NETWORK_PROVIDER, false);
    }
    private void getCurrentLocation(LocationManager lm, String provider, boolean triedGps) {
        try {
            if (!lm.isProviderEnabled(provider)) {
                if (!triedGps) getCurrentLocation(lm, LocationManager.GPS_PROVIDER, true);
                else Toast.makeText(this, "فعّل خدمة الموقع GPS ثم جرّب مجددًا", Toast.LENGTH_LONG).show();
                return;
            }
            lm.getCurrentLocation(provider, null, getMainExecutor(), l -> {
                if (l == null && !triedGps) { getCurrentLocation(lm, LocationManager.GPS_PROVIDER, true); return; }
                if (l == null) { Toast.makeText(this, "لم تتوفر إحداثيات جديدة؛ اقترب من نافذة أو جرّب مرة أخرى", Toast.LENGTH_LONG).show(); redraw(); return; }
                PrayerStore.saveLocation(this, l);
                PrayerStore.p(this).edit().putBoolean("force_refresh", true).apply();
                RefreshJobService.start(this);
                status.setText("تم تحديد الموقع؛ جارٍ جلب مواقيت أم القرى من الإنترنت...");
            });
        } catch (SecurityException e) { Toast.makeText(this, "يرجى منح صلاحية الموقع", Toast.LENGTH_LONG).show(); }
        catch (Exception e) { Toast.makeText(this, "تعذر تحديد الموقع، جرّب مجددًا", Toast.LENGTH_LONG).show(); }
    }
    private void requestNotification() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        } else Toast.makeText(this, "إذن الإشعارات متاح", Toast.LENGTH_SHORT).show();
    }
    private void requestExactAlarmIfNeeded() {
        AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 31 && am != null && !am.canScheduleExactAlarms()) {
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            intent.setData(Uri.parse("package:" + getPackageName()));
            try { startActivity(intent); }
            catch (Exception ignored) { Toast.makeText(this, "افتح إعدادات المنبهات الدقيقة للتطبيق", Toast.LENGTH_LONG).show(); }
        }
    }
    @Override public void onRequestPermissionsResult(int req, String[] permissions, int[] grant) {
        super.onRequestPermissionsResult(req, permissions, grant);
        if (req == GPS_REQUEST && hasLocationAccess()) requestLocation();
        else if (req == GPS_REQUEST) Toast.makeText(this, "الويدجت يحتاج صلاحية الموقع لحساب المواقيت", Toast.LENGTH_LONG).show();
        redraw();
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != AUDIO_PICKER || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri audio = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(audio, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            PrayerStore.p(this).edit().putString("custom_audio", audio.toString()).apply();
            Toast.makeText(this, "تم اختيار ملف الأذان بنجاح", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "تعذر حفظ إذن قراءة ملف الصوت", Toast.LENGTH_LONG).show(); }
    }
}
