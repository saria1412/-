package com.sarf.qasioun.prayer;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AlarmReceiver extends android.content.BroadcastReceiver {
    public static final String ACTION_ADHAN = "com.sarf.qasioun.prayer.ADHAN";
    public static final String CHANNEL_FALLBACK = "qasioun_adhan_alarm_v1";
    public static final String CHANNEL_FOREGROUND = "qasioun_adhan_playing_v1";
    @Override public void onReceive(Context c, Intent intent) {
        if (!ACTION_ADHAN.equals(intent.getAction())) return;
        long scheduledTime = intent.getLongExtra("at", 0);
        String prayer = intent.getStringExtra("prayer");
        if (scheduledTime <= 0 || prayer == null || !PrayerStore.adhanEnabled(c)) return;
        // Never play a stale alarm after location or schedule changed.
        PrayerEngine.Snapshot sn = PrayerEngine.snapshot(c);
        if (sn == null) return;
        boolean valid = false;
        for (PrayerEngine.Event e : sn.upcoming()) {
            if (e.epochMs() == scheduledTime && e.name().equals(prayer)) { valid = true; break; }
        }
        if (!valid || Math.abs(System.currentTimeMillis() - scheduledTime) > 30 * 60_000L) return;
        WidgetProvider.renderAll(c);
        try {
            Intent play = new Intent(c, AdhanService.class).setAction(AdhanService.START)
                    .putExtra("prayer", prayer);
            c.startForegroundService(play);
        } catch (Exception e) {
            // Sideloaded Android builds and restrictive launch policies can refuse FGS.
            fallbackNotify(c, prayer);
        }
    }

    private static PendingIntent pending(Context c, int requestCode, long when, String prayer) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION_ADHAN)
                .putExtra("at", when).putExtra("prayer", prayer);
        return PendingIntent.getBroadcast(c, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void scheduleAll(Context c) {
        AlarmManager alarms = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        Set<String> old = PrayerStore.p(c).getStringSet("alarm_codes", new HashSet<>());
        for (String str : old) try {
            int code = Integer.parseInt(str);
            PendingIntent pi = PendingIntent.getBroadcast(c, code,
                    new Intent(c, AlarmReceiver.class).setAction(ACTION_ADHAN),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { alarms.cancel(pi); pi.cancel(); }
        } catch (Exception ignored) {}
        HashSet<String> codes = new HashSet<>();
        PrayerEngine.Snapshot sn = PrayerEngine.snapshot(c);
        if (sn == null || !PrayerStore.adhanEnabled(c)) {
            PrayerStore.p(c).edit().putStringSet("alarm_codes", codes).apply(); return;
        }
        long now = System.currentTimeMillis();
        boolean exact = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms();
        for (PrayerEngine.Event e : sn.upcoming()) {
            if (e.epochMs() < now + 5_000L) continue;
            int dateCode = (int)(e.epochMs() / 86_400_000L);  // UTC day, stable request code
            int code = dateCode * 10 + e.index();
            try {
                PendingIntent pi = pending(c, code, e.epochMs(), e.name());
                if (exact) alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.epochMs(), pi);
                else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.epochMs(), pi);
                codes.add(String.valueOf(code));
            } catch (SecurityException ex) {
                // Graceful fallback when the exact-alarm permission gets revoked.
                try {
                    PendingIntent pi = pending(c, code, e.epochMs(), e.name());
                    alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.epochMs(), pi);
                    codes.add(String.valueOf(code));
                } catch (Exception ignore) {}
            }
        }
        PrayerStore.p(c).edit().putStringSet("alarm_codes", codes).apply();
    }

    public static void ensureChannels(Context c) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel quiet = new NotificationChannel(CHANNEL_FOREGROUND, "تشغيل الأذان", NotificationManager.IMPORTANCE_LOW);
        quiet.setSound(null, null);
        quiet.setShowBadge(false);
        nm.createNotificationChannel(quiet);
        NotificationChannel fallback = new NotificationChannel(CHANNEL_FALLBACK, "تنبيهات الصلاة الاحتياطية", NotificationManager.IMPORTANCE_HIGH);
        fallback.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
        nm.createNotificationChannel(fallback);
    }
    static Notification notification(Context c, String prayer, String channel, boolean ongoing) {
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(c, 45, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("حان موعد أذان " + prayer)
                .setContentText("قاسيون · مواقيت أم القرى")
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(pending)
                .setAutoCancel(!ongoing)
                .setOngoing(ongoing);
        if (ongoing) {
            Intent stop = new Intent(c, AdhanService.class).setAction(AdhanService.STOP);
            PendingIntent stopPi = PendingIntent.getService(c, 46, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPi).build());
        }
        return b.build();
    }
    static void fallbackNotify(Context c, String prayer) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        ensureChannels(c);
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1922, notification(c, prayer, CHANNEL_FALLBACK, false));
    }
}
