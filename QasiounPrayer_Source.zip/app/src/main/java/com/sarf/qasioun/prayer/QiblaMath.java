package com.sarf.qasioun.prayer;

/** True-north qibla bearing towards the Kaaba, spherical initial great-circle azimuth. */
public final class QiblaMath {
    private static final double KAABA_LAT = 21.422487;
    private static final double KAABA_LON = 39.826206;
    private QiblaMath() {}
    public static double bearing(double latitude, double longitude) {
        if (!Double.isFinite(latitude) || !Double.isFinite(longitude)
                || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180)
            throw new IllegalArgumentException("Invalid geographic coordinates");
        double p1=Math.toRadians(latitude),p2=Math.toRadians(KAABA_LAT);
        double dLon=Math.toRadians(KAABA_LON-longitude);
        double y=Math.sin(dLon)*Math.cos(p2);
        double x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dLon);
        if (Math.abs(x) < 1e-14 && Math.abs(y) < 1e-14) return 0.0;
        return wrap(Math.toDegrees(Math.atan2(y,x)));
    }
    public static double wrap(double value) {
        double v=value%360.0;
        return v<0.0?v+360.0:v;
    }
    public static double relative(double targetTrueBearing,double currentTrueHeading) {
        double v=wrap(targetTrueBearing-currentTrueHeading);
        return v>180.0?v-360.0:v;
    }
}
