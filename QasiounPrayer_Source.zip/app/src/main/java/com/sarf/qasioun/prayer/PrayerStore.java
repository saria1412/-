package com.sarf.qasioun.prayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class PrayerStore {
    public static final String PREFS = "prayer_store_v1";
    public static final String[] NAMES = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
    public static final String[] KEYS = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
    public static final DateTimeFormatter DATE_API = DateTimeFormatter.ofPattern("dd-MM-uuuu", Locale.US);
    private PrayerStore() {}
    public static SharedPreferences p(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public static boolean hasLocation(Context c) { return p(c).getBoolean("has_loc", false); }
    public static void saveLocation(Context c, Location l) {
        if (l == null || !Double.isFinite(l.getLatitude()) || !Double.isFinite(l.getLongitude())) return;
        p(c).edit().putBoolean("has_loc", true).putFloat("lat", (float) l.getLatitude())
                .putFloat("lon", (float) l.getLongitude()).putLong("location_at", System.currentTimeMillis()).apply();
    }
    public static double lat(Context c) { return p(c).getFloat("lat", 0f); }
    public static double lon(Context c) { return p(c).getFloat("lon", 0f); }
    public static boolean locationMatchesCache(Context c) {
        SharedPreferences ps = p(c);
        return ps.getBoolean("has_loc", false) && ps.contains("cached_lat")
                && PrayerMath.distanceKm(lat(c), lon(c), ps.getFloat("cached_lat", 0f), ps.getFloat("cached_lon", 0f)) < 2.0;
    }
    public static void putDays(Context c, LocalDate date, JSONObject today, JSONObject tomorrow, JSONObject dayAfter) {
        SharedPreferences.Editor ed = p(c).edit();
        ed.putString("day0", date.toString());
        ed.putString("day1", date.plusDays(1).toString());
        ed.putString("day2", date.plusDays(2).toString());
        ed.putString("json0", today.toString());
        ed.putString("json1", tomorrow.toString());
        ed.putString("json2", dayAfter.toString());
        ed.putFloat("cached_lat", (float) lat(c));
        ed.putFloat("cached_lon", (float) lon(c));
        ed.putLong("updated_at", System.currentTimeMillis());
        ed.remove("last_error");
        ed.apply();
    }
    public static JSONObject day(Context c, LocalDate d) {
        SharedPreferences ps = p(c);
        try {
            if (d.toString().equals(ps.getString("day0", ""))) return new JSONObject(ps.getString("json0", "{}"));
            if (d.toString().equals(ps.getString("day1", ""))) return new JSONObject(ps.getString("json1", "{}"));
            if (d.toString().equals(ps.getString("day2", ""))) return new JSONObject(ps.getString("json2", "{}"));
        } catch (Exception ignore) {}
        return null;
    }
    public static String lastError(Context c) { return p(c).getString("last_error", ""); }
    public static void error(Context c, String msg) { p(c).edit().putString("last_error", msg).apply(); }
    public static boolean adhanEnabled(Context c) { return p(c).getBoolean("adhan_enabled", false); }
}
