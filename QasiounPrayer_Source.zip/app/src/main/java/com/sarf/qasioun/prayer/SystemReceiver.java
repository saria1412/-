package com.sarf.qasioun.prayer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SystemReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        WidgetProvider.renderAll(context);
        RefreshJobService.start(context);
        AlarmReceiver.scheduleAll(context);
    }
}
