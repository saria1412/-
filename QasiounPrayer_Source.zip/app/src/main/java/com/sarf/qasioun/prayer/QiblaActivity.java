package com.sarf.qasioun.prayer;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** Live qibla compass; display direction only when a valid hardware heading is available. */
public class QiblaActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor rotationSensor, accelerometer, magnetometer;
    private boolean useRotationVector, hasAccelerometer, hasMagnetometer, hasReading;
    private int sensorAccuracy = SensorManager.SENSOR_STATUS_ACCURACY_LOW;
    private final float[] accel = new float[3], magnetic = new float[3];
    private double qiblaBearing, trueHeading, declination;
    private TextView bearingText, cityText, statusText;
    private CompassFace compass;
    private final int dark=Color.rgb(7,46,38), gold=Color.rgb(222,194,133), white=Color.rgb(247,244,232);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,40,33));
        getWindow().setNavigationBarColor(Color.rgb(7,40,33));
        if (!PrayerStore.hasLocation(this)) {
            LinearLayout blank=new LinearLayout(this);blank.setOrientation(LinearLayout.VERTICAL);
            blank.setBackgroundColor(dark);blank.setPadding(dp(24),dp(40),dp(24),dp(24));
            TextView v=label("يلزم تحديث الموقع من صفحة مواقيت الصلاة قبل حساب اتجاه القبلة.",18,white);
            blank.addView(v);setContentView(blank);return;
        }
        qiblaBearing=QiblaMath.bearing(PrayerStore.lat(this),PrayerStore.lon(this));
        GeomagneticField field=new GeomagneticField((float)PrayerStore.lat(this),
                (float)PrayerStore.lon(this),0f,System.currentTimeMillis());
        declination=field.getDeclination();
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(dark);page.setPadding(dp(22),dp(26),dp(22),dp(24));
        TextView heading=label("اتجاه القبلة",26,gold);
        heading.setTypeface(getResources().getFont(R.font.noto_kufi_arabic_bold));
        page.addView(heading);
        cityText=label(PrayerStore.city(this),15,white);
        LinearLayout.LayoutParams cityLp=new LinearLayout.LayoutParams(-1,-2);
        cityLp.topMargin=dp(8);page.addView(cityText,cityLp);
        bearingText=label(String.format(Locale.US,"زاوية القبلة من الشمال الحقيقي: %.1f°",qiblaBearing),15,gold);
        LinearLayout.LayoutParams bearingLp=new LinearLayout.LayoutParams(-1,-2);
        bearingLp.topMargin=dp(20);page.addView(bearingText,bearingLp);
        compass=new CompassFace();
        LinearLayout.LayoutParams compassLp=new LinearLayout.LayoutParams(-1,0,1);
        compassLp.topMargin=dp(18);compassLp.bottomMargin=dp(16);
        page.addView(compass,compassLp);
        statusText=label("جارٍ تهيئة مستشعرات البوصلة…",15,white);
        page.addView(statusText);
        TextView tip=label("أمسك الهاتف مستويًا، وابتعد عن المعادن والمغناطيس. إذا كانت القراءة غير مستقرة، حرّك الهاتف على شكل 8 للمعايرة.",12,Color.rgb(183,203,193));
        LinearLayout.LayoutParams tipLp=new LinearLayout.LayoutParams(-1,-2);
        tipLp.topMargin=dp(15);page.addView(tip,tipLp);
        setContentView(page);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            rotationSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer=sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            useRotationVector=rotationSensor!=null;
        }
    }
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int sp,int color){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);
        t.setTypeface(getResources().getFont(R.font.noto_kufi_arabic_regular));
        t.setIncludeFontPadding(false);t.setGravity(Gravity.CENTER);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return t;
    }
    @Override protected void onResume(){
        super.onResume();
        if(sensorManager==null || compass==null)return;
        if(useRotationVector) {
            boolean registered=sensorManager.registerListener(this,rotationSensor,SensorManager.SENSOR_DELAY_UI);
            if(!registered)statusText.setText("تعذر تشغيل مستشعر اتجاه الجهاز.");
        } else if(accelerometer!=null && magnetometer!=null){
            sensorManager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this,magnetometer,SensorManager.SENSOR_DELAY_UI);
            statusText.setText("جارٍ معايرة البوصلة…");
        } else statusText.setText("لا يدعم هذا الجهاز بوصلة مغناطيسية؛ زاوية القبلة أعلاه صحيحة لكن لا يمكن توجيه السهم آليًا.");
    }
    @Override protected void onPause(){
        if(sensorManager!=null)sensorManager.unregisterListener(this);
        super.onPause();
    }
    @Override public void onSensorChanged(SensorEvent event){
        if(compass==null)return;
        float[] orientation=new float[3];float[] r=new float[9];
        if(event.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR && useRotationVector){
            SensorManager.getRotationMatrixFromVector(r,event.values);
        }else if(!useRotationVector){
            if(event.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
                System.arraycopy(event.values,0,accel,0,3);hasAccelerometer=true;
            }else if(event.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD){
                System.arraycopy(event.values,0,magnetic,0,3);hasMagnetometer=true;
            }
            if(!hasAccelerometer || !hasMagnetometer || !SensorManager.getRotationMatrix(r,null,accel,magnetic))return;
        }else return;
        SensorManager.getOrientation(r,orientation);
        double heading=QiblaMath.wrap(Math.toDegrees(orientation[0])+declination);
        if(!Double.isFinite(heading))return;
        if(!hasReading){trueHeading=heading;hasReading=true;}
        else trueHeading=QiblaMath.wrap(trueHeading+QiblaMath.relative(heading,trueHeading)*0.18);
        double arrow=QiblaMath.relative(qiblaBearing,trueHeading);
        compass.setAngles(arrow,trueHeading);
        int accuracy=event.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR ? event.accuracy : sensorAccuracy;
        if(accuracy==SensorManager.SENSOR_STATUS_UNRELIABLE)statusText.setText("قراءة البوصلة غير موثوقة؛ أعد المعايرة بعيدًا عن المعادن.");
        else statusText.setText(String.format(Locale.US,"القبلة %.0f° من اتجاه أعلى الهاتف",Math.abs(arrow)) + (arrow<0 ? " إلى اليسار" : " إلى اليمين"));
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){
        if(sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD || sensor.getType()==Sensor.TYPE_ROTATION_VECTOR)
            sensorAccuracy=accuracy;
    }
    private final class CompassFace extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private double relativeAngle,headingAngle;
        CompassFace(){super(QiblaActivity.this);setContentDescription("بوصلة القبلة التفاعلية");}
        void setAngles(double relative,double heading){relativeAngle=relative;headingAngle=heading;invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(getWidth(),getHeight())*0.41f;
            if(r<5)return;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(0xFF8C8060);
            c.drawCircle(cx,cy,r,p);
            p.setColor(0x4479AB92);p.setStrokeWidth(dp(1));c.drawCircle(cx,cy,r*0.88f,p);
            for(int i=0;i<36;i++){
                double a=Math.toRadians(i*10-90);
                float x1=cx+(float)Math.cos(a)*r*0.91f,y1=cy+(float)Math.sin(a)*r*0.91f;
                float x2=cx+(float)Math.cos(a)*r*(i%3==0?0.80f:0.85f);
                float y2=cy+(float)Math.sin(a)*r*(i%3==0?0.80f:0.85f);
                p.setStrokeWidth(dp(i%3==0?2:1));p.setColor(0xFFB9B49D);
                c.drawLine(x1,y1,x2,y2,p);
            }
            p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(16));p.setColor(gold);
            c.drawText("ش",cx,cy-r*0.63f,p);
            c.drawText("ج",cx,cy+r*0.71f,p);
            c.drawText("غ",cx-r*0.69f,cy+dp(6),p);
            c.drawText("ق",cx+r*0.69f,cy+dp(6),p);
            c.save();c.rotate((float)relativeAngle,cx,cy);
            Path needle=new Path();
            needle.moveTo(cx,cy-r*0.57f);
            needle.lineTo(cx+dp(17),cy+dp(8));
            needle.lineTo(cx,cy-dp(4));
            needle.lineTo(cx-dp(17),cy+dp(8));needle.close();
            p.setColor(gold);c.drawPath(needle,p);
            c.restore();
            p.setColor(0xFF0A1511);c.drawRoundRect(cx-dp(18),cy-dp(18),cx+dp(18),cy+dp(18),dp(3),dp(3),p);
            p.setColor(gold);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));
            c.drawRect(cx-dp(18),cy-dp(18),cx+dp(18),cy+dp(18),p);
            p.setStyle(Paint.Style.FILL);p.setTextSize(dp(10));p.setColor(white);
            c.drawText("الكعبة",cx,cy+dp(4),p);
        }
    }
}
