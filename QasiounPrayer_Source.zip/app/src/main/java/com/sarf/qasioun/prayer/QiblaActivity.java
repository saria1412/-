package com.sarf.qasioun.prayer;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/**
 * Magnetic sensor heading -> actual screen heading -> magnetic declination -> true north.
 * The Qibla bearing is an initial great-circle course calculated from latest coordinates.
 * Sensor reliability is explicitly shown: a compass is never represented as surveying-grade.
 */
public final class QiblaActivity extends Activity implements SensorEventListener {
    private static final int REQUEST_FINE = 517;
    private final int dark = 0xFF08352C, panel = 0xFF11483C, gold = 0xFFE6C98E;
    private final int ivory = 0xFFF6F3E9, muted = 0xFFB8D0C4, red = 0xFFCF4D4F;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float[] accel = new float[3], magnetic = new float[3];
    private final float[] rotation = new float[9], adjusted = new float[9], angles = new float[3];
    private SensorManager sensors;
    private Sensor rotationSensor, accelerometer, magnetometer;
    private boolean useRotationVector, accelReady, magneticReady, headingReady;
    private int sensorAccuracy = -1, requestToken;
    private long lastPaintMs;
    private CancellationSignal pendingFix;
    private Runnable pendingTimeout;
    private double latitude, longitude, altitude, qiblaBearing, declination, heading;
    private Typeface regular, bold;
    private TextView cityView, locationView, bearingView, statusView, sensorView;
    private Button gpsButton;
    private CompassFace compass;

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getWindow().setStatusBarColor(0xFF062A23);
        getWindow().setNavigationBarColor(0xFF062A23);
        getWindow().getDecorView().setSystemUiVisibility(0);
        regular = getResources().getFont(R.font.noto_kufi_arabic_regular);
        bold = getResources().getFont(R.font.noto_kufi_arabic_bold);
        sensors = (SensorManager)getSystemService(SENSOR_SERVICE);
        if (sensors != null) {
            rotationSensor = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            accelerometer = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            useRotationVector = rotationSensor != null && magnetometer != null;
        }
        buildUi();
        loadStoredPosition();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private TextView text(String value, float sp, int color, boolean prominent) {
        TextView v = new TextView(this);
        v.setText(value); v.setTextSize(sp); v.setTextColor(color);
        v.setTypeface(prominent ? bold : regular);
        v.setIncludeFontPadding(false);
        v.setGravity(Gravity.CENTER);
        v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return v;
    }
    private GradientDrawable background(int color, int border, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (border != Color.TRANSPARENT) d.setStroke(dp(1), border);
        return d;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setBackgroundColor(dark);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setPadding(dp(17), dp(23), dp(17), dp(28));
        scroll.addView(page);
        TextView headingTitle = text("بوصلة القبلة", 25, gold, true);
        page.addView(headingTitle);
        TextView subtitle = text("اتجاه الكعبة المشرفة من موقعك", 12, muted, false);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(4); page.addView(subtitle, subtitleLp);

        LinearLayout cityPanel = new LinearLayout(this);
        cityPanel.setOrientation(LinearLayout.VERTICAL);
        cityPanel.setGravity(Gravity.CENTER);
        cityPanel.setPadding(dp(13), dp(10), dp(13), dp(10));
        cityPanel.setBackground(background(panel, 0x777C9B7C, 16));
        LinearLayout.LayoutParams cityPanelLp = new LinearLayout.LayoutParams(-1, -2);
        cityPanelLp.topMargin = dp(16); page.addView(cityPanel, cityPanelLp);
        cityView = text("الموقع غير محدد", 17, ivory, true);
        cityPanel.addView(cityView);
        locationView = text("اضغط تحديث الموقع لتحديد القبلة", 11, muted, false);
        LinearLayout.LayoutParams locationLp = new LinearLayout.LayoutParams(-1, -2);
        locationLp.topMargin = dp(4); cityPanel.addView(locationView, locationLp);

        bearingView = text("—", 14, gold, true);
        LinearLayout.LayoutParams bearingLp = new LinearLayout.LayoutParams(-1, -2);
        bearingLp.topMargin = dp(16); page.addView(bearingView, bearingLp);

        compass = new CompassFace();
        LinearLayout.LayoutParams compassLp = new LinearLayout.LayoutParams(-1, dp(322));
        compassLp.topMargin = dp(9); page.addView(compass, compassLp);

        statusView = text("جارٍ تهيئة مستشعر اتجاه الهاتف…", 17, ivory, true);
        page.addView(statusView);
        sensorView = text("يُحسب الاتجاه من الشمال الحقيقي بعد تصحيح الانحراف المغناطيسي.", 11, muted, false);
        LinearLayout.LayoutParams sensorLp = new LinearLayout.LayoutParams(-1, -2);
        sensorLp.topMargin = dp(4); page.addView(sensorView, sensorLp);

        gpsButton = new Button(this);
        gpsButton.setAllCaps(false);
        gpsButton.setText("⌖  تحديث الموقع بدقة GPS");
        gpsButton.setTextColor(dark);
        gpsButton.setTypeface(bold);
        gpsButton.setTextSize(13);
        gpsButton.setMinHeight(dp(49));
        gpsButton.setBackgroundTintList(null);
        gpsButton.setBackground(background(gold, Color.TRANSPARENT, 14));
        gpsButton.setOnClickListener(v -> requestAccurateLocation());
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, -2);
        buttonLp.topMargin = dp(20); page.addView(gpsButton, buttonLp);

        TextView tip = text("أمسك الهاتف أفقيًا بعيدًا عن الأجهزة المعدنية والمغناطيس. إن كانت الدقة منخفضة، حرّك الهاتف على شكل 8، ثم أعد المحاولة.", 11, muted, false);
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(-1, -2);
        tipLp.topMargin = dp(13); page.addView(tip, tipLp);
        setContentView(scroll);
    }
    private void loadStoredPosition() {
        if (!PrayerStore.hasLocation(this)) {
            cityView.setText("موقعك غير محدد");
            bearingView.setText("حدد موقعك أولًا للحصول على اتجاه القبلة");
            locationView.setText("الموقع الدقيق يحتاج إذن تحديد الموقع");
            compass.setAvailable(false);
            return;
        }
        latitude = PrayerStore.lat(this);
        longitude = PrayerStore.lon(this);
        altitude = PrayerStore.p(this).getFloat("location_altitude", 0f);
        updateBearing();
        cityView.setText(PrayerStore.city(this));
        float acc = PrayerStore.p(this).getFloat("location_accuracy", -1f);
        long age = System.currentTimeMillis() - PrayerStore.p(this).getLong("location_at", 0);
        String confidence = acc >= 0 ? String.format(Locale.US, "±%.0f متر", acc) : "غير معروفة";
        String stale = age > 12L * 3600000L ? " · الموقع قديم؛ حدّثه" : "";
        locationView.setText("دقة آخر موقع: " + confidence + stale);
        compass.setAvailable(true);
    }
    private void updateBearing() {
        qiblaBearing = QiblaMath.bearing(latitude, longitude);
        declination = new GeomagneticField((float)latitude, (float)longitude,
                (float)altitude, System.currentTimeMillis()).getDeclination();
        bearingView.setText(String.format(Locale.US,
                "زاوية القبلة: %.1f° من الشمال الحقيقي", qiblaBearing));
        if (compass != null && headingReady)
            compass.setAngles(QiblaMath.relative(qiblaBearing, heading), heading);
    }
    private boolean hasFineAccess() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }
    private void requestAccurateLocation() {
        if (!hasFineAccess()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_FINE);
            return;
        }
        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) {
            locationView.setText("خدمات الموقع غير متاحة");
            return;
        }
        boolean gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean net = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (!gps && !net) {
            locationView.setText("شغّل خدمة الموقع GPS وأعد المحاولة");
            return;
        }
        gpsButton.setEnabled(false);
        locationView.setText("جارٍ تحديد إحداثيات جديدة…");
        fetchLocation(lm, gps ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER, gps && net);
    }
    private void fetchLocation(LocationManager lm, String provider, boolean allowNetworkFallback) {
        cancelPending();
        final int token = ++requestToken;
        pendingFix = new CancellationSignal();
        pendingTimeout = () -> {
            if (token != requestToken) return;
            cancelPending();
            if (allowNetworkFallback) {
                locationView.setText("تعذر استقبال GPS؛ جارٍ تجربة الشبكة…");
                fetchLocation(lm, LocationManager.NETWORK_PROVIDER, false);
            } else {
                gpsButton.setEnabled(true);
                locationView.setText("تعذر تحديد موقع جديد. حاول قرب نافذة أو في مكان مفتوح.");
            }
        };
        main.postDelayed(pendingTimeout, provider.equals(LocationManager.GPS_PROVIDER) ? 16000 : 9000);
        try {
            lm.getCurrentLocation(provider, pendingFix, getMainExecutor(), location -> {
                if (token != requestToken) return;
                cancelPending();
                if (location == null || !Double.isFinite(location.getLatitude())
                        || !Double.isFinite(location.getLongitude())) {
                    if (allowNetworkFallback) {
                        locationView.setText("جارٍ تجربة موقع الشبكة…");
                        fetchLocation(lm, LocationManager.NETWORK_PROVIDER, false);
                    } else {
                        gpsButton.setEnabled(true);
                        locationView.setText("لم يُعثر على موقع حالي. أعد المحاولة.");
                    }
                    return;
                }
                PrayerStore.saveLocation(this, location);
                gpsButton.setEnabled(true);
                loadStoredPosition();
                if (location.hasAccuracy() && location.getAccuracy() > 100f)
                    locationView.append(" · دقة ضعيفة؛ يفضّل GPS في مكان مفتوح");
                PrayerStore.p(this).edit().putBoolean("force_refresh", true).apply();
                RefreshJobService.start(this);
                new Thread(() -> CityResolver.resolve(this), "QiblaCityLookup").start();
            });
        } catch (SecurityException ex) {
            cancelPending(); gpsButton.setEnabled(true);
            locationView.setText("يلزم إذن الموقع الدقيق من إعدادات الهاتف");
        } catch (Exception ex) {
            cancelPending(); gpsButton.setEnabled(true);
            locationView.setText("تعذر تحديث الموقع؛ حاول مرة أخرى");
        }
    }
    private void cancelPending() {
        ++requestToken;
        if (pendingTimeout != null) { main.removeCallbacks(pendingTimeout); pendingTimeout = null; }
        if (pendingFix != null) {
            pendingFix.cancel(); pendingFix = null;
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_FINE) {
            if (hasFineAccess()) requestAccurateLocation();
            else locationView.setText("فعّل الموقع الدقيق (وليس التقريبي) لتحسين اتجاه القبلة");
        }
    }
    @Override protected void onResume() {
        super.onResume();
        hasReadingReset();
        if (sensors == null) { sensorView.setText("مستشعرات البوصلة غير متاحة"); return; }
        if (useRotationVector) {
            if (!sensors.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME))
                sensorView.setText("تعذر تفعيل مستشعر الاتجاه");
            if (magnetometer != null)
                sensors.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);
        } else if (accelerometer != null && magnetometer != null) {
            sensors.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
            sensors.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_GAME);
        } else {
            sensorView.setText("هذا الجهاز لا يوفر البوصلة المطلوبة؛ استخدم زاوية القبلة الرقمية.");
            statusView.setText("المستشعر غير متاح");
        }
    }
    private void hasReadingReset() {
        headingReady = false; accelReady = false; magneticReady = false;
        lastPaintMs = 0; compass.setReading(false);
    }
    @Override protected void onPause() {
        if (sensors != null) sensors.unregisterListener(this);
        cancelPending(); gpsButton.setEnabled(true);
        super.onPause();
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD ||
                sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) sensorAccuracy = accuracy;
    }
    @Override public void onSensorChanged(SensorEvent event) {
        if (!PrayerStore.hasLocation(this) || sensors == null) return;
        int type = event.sensor.getType();
        if (type == Sensor.TYPE_MAGNETIC_FIELD) {
            sensorAccuracy = event.accuracy;
            if (event.values.length >= 3) {
                System.arraycopy(event.values, 0, magnetic, 0, 3);
                magneticReady = true;
            }
            if (useRotationVector) return; // Magnetometer is used for reliability status only.
        } else if (type == Sensor.TYPE_ACCELEROMETER && !useRotationVector) {
            if (event.values.length >= 3) {
                System.arraycopy(event.values, 0, accel, 0, 3);
                accelReady = true;
            }
        } else if (type == Sensor.TYPE_ROTATION_VECTOR && useRotationVector) {
            SensorManager.getRotationMatrixFromVector(rotation, event.values);
        } else return;
        if (!useRotationVector) {
            if (!accelReady || !magneticReady ||
                    !SensorManager.getRotationMatrix(rotation, null, accel, magnetic)) return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastPaintMs < 65) return;
        lastPaintMs = now;
        float[] screenMatrix = adjusted;
        int rotationCode = getWindowManager().getDefaultDisplay().getRotation();
        boolean success;
        if (rotationCode == Surface.ROTATION_90)
            success = SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_Y,
                    SensorManager.AXIS_MINUS_X, screenMatrix);
        else if (rotationCode == Surface.ROTATION_180)
            success = SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_MINUS_X,
                    SensorManager.AXIS_MINUS_Y, screenMatrix);
        else if (rotationCode == Surface.ROTATION_270)
            success = SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_MINUS_Y,
                    SensorManager.AXIS_X, screenMatrix);
        else { System.arraycopy(rotation, 0, screenMatrix, 0, 9); success = true; }
        if (!success) return;
        SensorManager.getOrientation(screenMatrix, angles);
        double azimuth = QiblaMath.wrap(Math.toDegrees(angles[0]) + declination);
        if (!Double.isFinite(azimuth)) return;
        if (!headingReady) {
            heading = azimuth; headingReady = true;
        } else {
            // Circular filtering prevents 359° -> 0° jumps and reduces compass jitter.
            heading = QiblaMath.wrap(heading + QiblaMath.relative(azimuth, heading) * 0.22);
        }
        double delta = QiblaMath.relative(qiblaBearing, heading);
        compass.setAngles(delta, heading);
        if (sensorAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE) {
            statusView.setText("⚠  قراءة البوصلة غير موثوقة");
            sensorView.setText("ابتعد عن المعادن وحرّك الهاتف على شكل 8 لمعايرة المستشعر.");
        } else if (Math.abs(Math.toDegrees(angles[1])) > 65 ||
                Math.abs(Math.toDegrees(angles[2])) > 65) {
            statusView.setText("ضع الهاتف أفقيًا للحصول على اتجاه ثابت");
            sensorView.setText("استخدم البوصلة بعيدًا عن مصادر التشويش المغناطيسي.");
        } else {
            if (Math.abs(delta) <= 3.0) statusView.setText("✓  أنت باتجاه القبلة");
            else statusView.setText(String.format(Locale.US, "حرّك الهاتف %s %.0f°",
                    delta > 0 ? "يمينًا" : "يسارًا", Math.abs(delta)));
            String reliability = sensorAccuracy >= SensorManager.SENSOR_STATUS_ACCURACY_HIGH ? "جيدة" :
                    sensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM ? "متوسطة" :
                    sensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_LOW ? "منخفضة" : "غير محددة";
            sensorView.setText("دقة المستشعر: " + reliability +
                    "  ·  الشمال الحقيقي مصحح مغناطيسيًا");
        }
    }

    /** Rotating cardinal dial and a gold arrow that points to Kaaba relative to the phone. */
    private final class CompassFace extends View {
        private final Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
        private double delta, currentHeading;
        private boolean enabled, reading;
        CompassFace() {
            super(QiblaActivity.this);
            setContentDescription("بوصلة القبلة: سهم ذهبي يشير إلى الكعبة مع مؤشر للشمال الحقيقي");
        }
        void setAvailable(boolean value) { enabled = value; invalidate(); }
        void setReading(boolean value) { reading = value; invalidate(); }
        void setAngles(double angle, double trueHeading) {
            delta = angle; currentHeading = trueHeading; enabled = true; reading = true;
            invalidate();
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            float r = Math.min(getWidth(), getHeight()) * .455f;
            if (r < dp(38)) return;
            brush.setShader(new LinearGradient(cx-r, cy-r, cx+r, cy+r,
                    new int[]{0xFF0E5947,0xFF082F29,0xFF0B483A},null,Shader.TileMode.CLAMP));
            brush.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy, r, brush);
            brush.setShader(null);
            brush.setColor(0xFFBDA36E); brush.setStyle(Paint.Style.STROKE);
            brush.setStrokeWidth(dp(2.3f)); c.drawCircle(cx, cy, r, brush);
            brush.setColor(0x5278B9A0); brush.setStrokeWidth(dp(1));
            c.drawCircle(cx, cy, r*.86f, brush);

            // Geographic bearings are fixed to the earth. Rotate the dial against the phone.
            for (int i=0; i<72; i++) {
                double angle=Math.toRadians(i*5 - 90 - (reading ? currentHeading : 0));
                float outer=r*.96f;
                float inner=r*(i%18==0?.83f:i%3==0?.87f:.91f);
                float x1=cx+(float)Math.cos(angle)*inner;
                float y1=cy+(float)Math.sin(angle)*inner;
                float x2=cx+(float)Math.cos(angle)*outer;
                float y2=cy+(float)Math.sin(angle)*outer;
                brush.setStrokeWidth(dp(i%18==0 ? 2.4f : 1f));
                brush.setColor(i%18==0 ? gold : 0x887FA795);
                c.drawLine(x1,y1,x2,y2,brush);
            }
            brush.setStyle(Paint.Style.FILL);
            brush.setTextAlign(Paint.Align.CENTER);
            brush.setTextSize(dp(18));
            brush.setTypeface(bold);
            String[] points={"ش", "ق", "ج", "غ"};
            for(int i=0;i<4;i++) {
                double a = Math.toRadians(i*90-90-(reading?currentHeading:0));
                float x=cx+(float)Math.cos(a)*r*.73f;
                float y=cy+(float)Math.sin(a)*r*.73f;
                brush.setColor(i==0?red:0xFFD1D8C5);
                c.drawText(points[i],x,y+dp(6),brush);
            }
            // Fixed marker at the phone's screen top (the heading reference).
            Path top=new Path();
            top.moveTo(cx,cy-r*.99f);
            top.lineTo(cx-dp(8),cy-r*.86f);
            top.lineTo(cx+dp(8),cy-r*.86f);
            top.close();
            brush.setColor(ivory);c.drawPath(top,brush);

            if (enabled && reading) {
                c.save(); c.rotate((float)delta,cx,cy);
                // Arrow's point lies toward the Kaaba, not permanently toward screen north.
                Path shaft=new Path();
                shaft.moveTo(cx, cy-r*.62f);
                shaft.lineTo(cx+dp(14), cy-r*.37f);
                shaft.lineTo(cx+dp(5), cy-r*.38f);
                shaft.lineTo(cx+dp(5), cy+dp(23));
                shaft.lineTo(cx-dp(5), cy+dp(23));
                shaft.lineTo(cx-dp(5), cy-r*.38f);
                shaft.lineTo(cx-dp(14), cy-r*.37f);
                shaft.close();
                brush.setColor(gold);c.drawPath(shaft,brush);
                c.restore();
            }
            // Small central Kaaba graphic with golden embroidered band.
            brush.setStyle(Paint.Style.FILL);
            brush.setColor(0xFF071912);
            c.drawRoundRect(cx-dp(23),cy-dp(22),cx+dp(23),cy+dp(24),dp(5),dp(5),brush);
            brush.setColor(gold);
            c.drawRoundRect(cx-dp(23),cy-dp(10),cx+dp(23),cy-dp(5),dp(1),dp(1),brush);
            brush.setStyle(Paint.Style.STROKE);brush.setStrokeWidth(dp(1.5f));
            c.drawRoundRect(cx-dp(23),cy-dp(22),cx+dp(23),cy+dp(24),dp(5),dp(5),brush);
            brush.setStyle(Paint.Style.FILL);brush.setTypeface(bold);
            brush.setTextSize(dp(11));brush.setTextAlign(Paint.Align.CENTER);
            brush.setColor(ivory);
            c.drawText("الكعبة",cx,cy+dp(11),brush);
        }
    }
}
