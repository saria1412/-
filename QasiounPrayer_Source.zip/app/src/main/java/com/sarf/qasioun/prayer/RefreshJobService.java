package com.sarf.qasioun.prayer;

import android.Manifest;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import org.json.JSONObject;
import java.time.LocalDate;

public class RefreshJobService extends JobService {
    private static final int JOB_IMMEDIATE = 31660;
    private static final int JOB_PERIODIC = 31661;
    private volatile boolean cancelled;

    public static void start(Context context) {
        JobScheduler js = (JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        ComponentName component = new ComponentName(context, RefreshJobService.class);
        JobInfo immediate = new JobInfo.Builder(JOB_IMMEDIATE, component)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setOverrideDeadline(60_000L).build();
        JobInfo periodic = new JobInfo.Builder(JOB_PERIODIC, component)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(60 * 60_000L)
                .setPersisted(true).build();
        js.schedule(immediate);
        js.schedule(periodic);
    }

    @Override public boolean onStartJob(JobParameters params) {
        cancelled = false;
        new Thread(() -> {
            try { refresh(getApplicationContext()); }
            finally { if (!cancelled) jobFinished(params, false); }
        }, "QasiounPrayerRefresh").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { cancelled = true; return true; }

    static void refresh(Context c) {
        if (!PrayerStore.hasLocation(c)) {
            PrayerStore.error(c, "يفترض منح إذن الموقع أولًا");
            WidgetProvider.renderAll(c); return;
        }
        // Only access location in the background if Android permission was explicitly granted.
        if (c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                LocationManager lm = (LocationManager)c.getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String provider : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER}) {
                    Location x = lm.getLastKnownLocation(provider);
                    if (x != null && (best == null || x.getTime() > best.getTime())) best = x;
                }
                if (best != null && System.currentTimeMillis() - best.getTime() < 2 * 60 * 60_000L) {
                    if (PrayerMath.distanceKm(best.getLatitude(), best.getLongitude(), PrayerStore.lat(c), PrayerStore.lon(c)) > 2.0)
                        PrayerStore.saveLocation(c, best);
                }
            } catch (Exception ignore) { }
        }
        LocalDate today = LocalDate.now();
        boolean force = PrayerStore.p(c).getBoolean("force_refresh", false);
        if (force || !PrayerStore.locationMatchesCache(c) ||
                !today.toString().equals(PrayerStore.p(c).getString("day0", "")) ||
                !PrayerMath.isFresh(PrayerStore.p(c).getLong("updated_at", 0L), System.currentTimeMillis(), 4)) {
            try {
                double lat = PrayerStore.lat(c), lon = PrayerStore.lon(c);
                JSONObject first = PrayerApi.day(today, lat, lon);
                JSONObject second = PrayerApi.day(today.plusDays(1), lat, lon);
                JSONObject third = PrayerApi.day(today.plusDays(2), lat, lon);
                // Discard a response if the location was changed while network requests were running.
                if (PrayerMath.distanceKm(lat, lon, PrayerStore.lat(c), PrayerStore.lon(c)) < 0.1) {
                    PrayerStore.putDays(c, today, first, second, third);
                } else {
                    PrayerStore.error(c, "تغير الموقع أثناء تحديث المواقيت؛ ستتم إعادة المحاولة");
                }
            } catch (Exception e) { PrayerStore.error(c, "تعذر الاتصال بمصدر المواقيت: " + e.getClass().getSimpleName()); }
        }
        PrayerStore.p(c).edit().putBoolean("force_refresh", false).apply();
        if (!PrayerStore.cityKnown(c)) CityResolver.resolve(c);
        WidgetProvider.renderAll(c);
        AlarmReceiver.scheduleAll(c);
    }
}
