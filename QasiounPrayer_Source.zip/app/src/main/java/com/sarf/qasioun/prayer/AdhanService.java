package com.sarf.qasioun.prayer;

import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;

/** Foreground playback of the CC0 Adhan, started by an exact prayer alarm. */
public class AdhanService extends Service {
    public static final String START = "com.sarf.qasioun.prayer.START_ADHAN";
    public static final String STOP = "com.sarf.qasioun.prayer.STOP_ADHAN";
    private MediaPlayer player;
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!START.equals(intent.getAction()) || !PrayerStore.adhanEnabled(this)) { stopSelf(); return START_NOT_STICKY; }
        String prayer = intent.getStringExtra("prayer");
        if (prayer == null) prayer = "الصلاة";
        AlarmReceiver.ensureChannels(this);
        try {
            startForeground(1901, AlarmReceiver.notification(this, prayer, AlarmReceiver.CHANNEL_FOREGROUND, true));
            releasePlayer();
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            String custom = PrayerStore.p(this).getString("custom_audio", "");
            Uri uri = custom.isEmpty()
                    ? Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.adhan)
                    : Uri.parse(custom);
            player.setDataSource(this, uri);
            player.setOnCompletionListener(mp -> stopSelf());
            player.setOnErrorListener((mp, what, extra) -> { stopSelf(); return true; });
            player.setOnPreparedListener(MediaPlayer::start);
            player.prepareAsync();
        } catch (Exception e) {
            Log.w("QasiounPrayer", "Adhan sound unavailable", e);
            AlarmReceiver.fallbackNotify(this, prayer);
            stopSelf();
        }
        return START_NOT_STICKY;
    }
    private void releasePlayer() { if (player != null) { try { player.stop(); } catch (Exception ignore){} player.release(); player = null; } }
    @Override public void onDestroy() { releasePlayer(); super.onDestroy(); }
}
