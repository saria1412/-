package com.sarf.qasioun.prayer;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/** Resolve a city for the saved position. Runs strictly on a worker thread. */
public final class CityResolver {
    private CityResolver() {}

    public static void resolve(Context context) {
        Context c = context.getApplicationContext();
        if (!PrayerStore.hasLocation(c) || PrayerStore.cityKnown(c)) return;
        double lat = PrayerStore.lat(c), lon = PrayerStore.lon(c);
        String name = null;
        if (Geocoder.isPresent()) {
            try {
                Geocoder geocoder = new Geocoder(c, new Locale("ar", "SA"));
                @SuppressWarnings("deprecation")
                List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address a = addresses.get(0);
                    name = firstUseful(a.getLocality(), a.getSubAdminArea(), a.getAdminArea());
                }
            } catch (Exception ignored) { }
        }
        if (name == null) name = networkReverseGeocode(lat, lon);
        if (name == null || name.isEmpty()) return;
        // Never save a stale city if the user moved while resolution was in flight.
        PrayerStore.saveCity(c, lat, lon, name);
        WidgetProvider.renderAll(c);
    }

    private static String firstUseful(String... candidates) {
        for (String s : candidates) if (s != null && !s.trim().isEmpty() && s.trim().length() < 72)
            return s.trim();
        return null;
    }
    private static String networkReverseGeocode(double lat, double lon) {
        HttpURLConnection conn = null;
        try {
            String url = String.format(Locale.US,
                    "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=%.6f&longitude=%.6f&localityLanguage=ar",
                    lat, lon);
            conn = (HttpURLConnection)new URL(url).openConnection();
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "QasiounPrayer-Android/0.3");
            conn.setConnectTimeout(5000); conn.setReadTimeout(5000);
            if (conn.getResponseCode() != 200) return null;
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b = new byte[4096]; int n;
                while ((n=in.read(b)) != -1) {
                    out.write(b,0,n);
                    if (out.size()>64_000) return null;
                }
                JSONObject object = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
                return firstUseful(object.optString("city",null), object.optString("locality",null),
                        object.optString("principalSubdivision",null));
            }
        } catch (Exception ignored) { return null; }
        finally { if (conn != null) conn.disconnect(); }
    }
}
