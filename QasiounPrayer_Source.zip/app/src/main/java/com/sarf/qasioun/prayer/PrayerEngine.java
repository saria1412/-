package com.sarf.qasioun.prayer;

import android.content.Context;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.text.SimpleDateFormat;

public final class PrayerEngine {
    public record Event(String name, int index, long epochMs, String textTime) {}
    public record Snapshot(List<Event> today, List<Event> upcoming, Event next, Event sunrise, String hijri, String tz,
                           long updatedAt, boolean locationValid) {}
    private PrayerEngine() {}

    public static Snapshot snapshot(Context c) {
        LocalDate date = LocalDate.now();
        JSONObject today = PrayerStore.day(c, date), tomorrow = PrayerStore.day(c, date.plusDays(1));
        boolean locationValid = PrayerStore.locationMatchesCache(c);
        if (today == null || tomorrow == null || !locationValid) return null;
        try {
            String zone = today.getJSONObject("meta").getString("timezone");
            ZoneId.of(zone);
            ArrayList<Event> nowEvents = parseEvents(today, date, zone);
            Event sunrise = parseSunrise(today,date,zone);
            ArrayList<Event> allEvents = new ArrayList<>(nowEvents);
            allEvents.addAll(parseEvents(tomorrow, date.plusDays(1), zone));
            allEvents.sort(Comparator.comparingLong(Event::epochMs));
            long now = System.currentTimeMillis();
            Event next = null;
            for (Event e : allEvents) if (e.epochMs() > now) { next = e; break; }
            JSONObject hijri = today.getJSONObject("date").getJSONObject("hijri");
            JSONObject month = hijri.getJSONObject("month");
            String hijriText = hijri.getString("day") + " " + month.optString("ar", "") + " " + hijri.getString("year") + "هـ";
            return new Snapshot(nowEvents, allEvents, next, sunrise, hijriText, zone,
                    PrayerStore.p(c).getLong("updated_at", 0L), true);
        } catch (Exception error) { return null; }
    }

    static ArrayList<Event> parseEvents(JSONObject data, LocalDate date, String zone) throws Exception {
        JSONObject times = data.getJSONObject("timings");
        ArrayList<Event> events = new ArrayList<>();
        for (int i=0; i<PrayerStore.KEYS.length; i++) {
            String text = times.getString(PrayerStore.KEYS[i]);
            // API can return "04:50 (+03)" or ISO8601; normalize both.
            if (text.contains("T")) text = text.substring(text.indexOf('T')+1);
            text = text.substring(0, 5);
            long epoch = PrayerMath.epochMillis(date, text, zone);
            events.add(new Event(PrayerStore.NAMES[i], i, epoch, text));
        }
        return events;
    }

    static Event parseSunrise(JSONObject data,LocalDate date,String zone) throws Exception {
        String raw=data.getJSONObject("timings").getString("Sunrise");
        if (raw.contains("T")) raw=raw.substring(raw.indexOf('T')+1);
        String clock=raw.substring(0,5);
        return new Event("الشروق", -1, PrayerMath.epochMillis(date,clock,zone),clock);
    }
    public static String formatSunrise(Event event) { return event.textTime(); }
    public static String format(Event event, String zone) {
        SimpleDateFormat f = new SimpleDateFormat("hh:mm a", Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone(zone));
        return f.format(new Date(event.epochMs())).replace("AM", "ص").replace("PM", "م");
    }
    public static String formatShort(Event event, String zone) {
        SimpleDateFormat f = new SimpleDateFormat("hh:mm", Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone(zone));
        return f.format(new Date(event.epochMs()));
    }
}
