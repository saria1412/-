#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/qasioun-prayer-test
javac -encoding UTF-8 -d /tmp/qasioun-prayer-test app/src/main/java/com/sarf/qasioun/prayer/PrayerMath.java app/src/main/java/com/sarf/qasioun/prayer/QiblaMath.java tests/PrayerMathTest.java tests/QiblaMathTest.java
java -cp /tmp/qasioun-prayer-test PrayerMathTest
java -cp /tmp/qasioun-prayer-test QiblaMathTest
python3 tests/validate.py
