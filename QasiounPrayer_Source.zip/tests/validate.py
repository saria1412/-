from pathlib import Path
from xml.etree import ElementTree as etree
import re
p=Path(__file__).resolve().parents[1]
xmls=list((p/'app/src/main').rglob('*.xml'))
for file in xmls:
    etree.parse(str(file))
print('PASS XML',len(xmls))
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
assert 'SCHEDULE_EXACT_ALARM' in manifest
assert 'ACCESS_BACKGROUND_LOCATION' in manifest
assert 'POST_NOTIFICATIONS' in manifest
print('PASS Android permission declaration')
api=(p/'app/src/main/java/com/sarf/qasioun/prayer/PrayerApi.java').read_text()
assert 'method=4&calendarMethod=UAQ&school=0' in api
assert 'https://api.aladhan.com/v1/timings/' in api
print('PASS Umm al Qura API parameters')
alarms=(p/'app/src/main/java/com/sarf/qasioun/prayer/AlarmReceiver.java').read_text()
assert 'setExactAndAllowWhileIdle' in alarms
assert 'canScheduleExactAlarms()' in alarms
print('PASS exact alarm capability check')
assert (p/'app/src/main/res/mipmap-xxxhdpi/ic_launcher.webp').stat().st_size>500
print('PASS actual app icon')

# v0.3 user acceptance checks
store=(p/'app/src/main/java/com/sarf/qasioun/prayer/PrayerStore.java').read_text()
engine=(p/'app/src/main/java/com/sarf/qasioun/prayer/PrayerEngine.java').read_text()
widget=(p/'app/src/main/res/layout/prayer_widget.xml').read_text()
provider=(p/'app/src/main/java/com/sarf/qasioun/prayer/WidgetProvider.java').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
assert 'android:label="مواقيت الصلاة"' in manifest
assert '.QiblaActivity' in manifest
assert 'Sunrise' in api and 'Sunrise' in engine and 'R.id.t_sunrise' in provider
assert 'Sunrise' not in (p/'app/src/main/java/com/sarf/qasioun/prayer/AlarmReceiver.java').read_text()
assert 'widget_title' not in widget and 'widget_status' not in widget and 'قاسيون' not in widget
assert 'widget_city' in widget and 'PrayerStore.city(context)' in provider
assert 'minHeight="106dp"' in (p/'app/src/main/res/xml/prayer_widget.xml').read_text()
assert 'CityResolver.resolve(c)' in (p/'app/src/main/java/com/sarf/qasioun/prayer/RefreshJobService.java').read_text()
assert 'QiblaMath.relative' in (p/'app/src/main/java/com/sarf/qasioun/prayer/QiblaActivity.java').read_text()
for name in ['regular','medium','bold']:
    assert (p/f'app/src/main/res/font/noto_kufi_arabic_{name}.ttf').stat().st_size>10000
print('PASS v0.3 name sunrise city qibla compact widget embedded fonts')
