from pathlib import Path
from xml.etree import ElementTree as etree
import re
p=Path(__file__).resolve().parents[1]
xmls=list((p/'app/src/main').rglob('*.xml'))
for file in xmls:
    etree.parse(str(file))
print('PASS XML',len(xmls))
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
assert 'SCHEDULE_EXACT_ALARM' in manifest
assert 'ACCESS_BACKGROUND_LOCATION' in manifest
assert 'POST_NOTIFICATIONS' in manifest
print('PASS Android permission declaration')
api=(p/'app/src/main/java/com/sarf/qasioun/prayer/PrayerApi.java').read_text()
assert 'method=4&calendarMethod=UAQ&school=0' in api
assert 'https://api.aladhan.com/v1/timings/' in api
print('PASS Umm al Qura API parameters')
alarms=(p/'app/src/main/java/com/sarf/qasioun/prayer/AlarmReceiver.java').read_text()
assert 'setExactAndAllowWhileIdle' in alarms
assert 'canScheduleExactAlarms()' in alarms
print('PASS exact alarm capability check')
assert (p/'app/src/main/res/mipmap-xxxhdpi/ic_launcher.webp').stat().st_size>500
print('PASS actual app icon')
