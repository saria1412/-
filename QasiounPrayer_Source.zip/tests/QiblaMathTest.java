import com.sarf.qasioun.prayer.QiblaMath;
public class QiblaMathTest {
    private static void check(boolean passed,String label) { if (!passed) throw new AssertionError(label);System.out.println("PASS "+label); }
    public static void main(String[] args) {
        check(QiblaMath.bearing(21.422487,39.826206)==0,"Kaaba point degenerate");
        check(QiblaMath.bearing(24.7136,46.6753)>230 && QiblaMath.bearing(24.7136,46.6753)<260,"Riyadh qibla southwest");
        check(QiblaMath.bearing(33.5138,36.2765)>155 && QiblaMath.bearing(33.5138,36.2765)<180,"Damascus qibla south");
        check(QiblaMath.wrap(-10)==350,"negative heading wrapped");
        check(QiblaMath.relative(10,350)==20,"bearing crosses north");
        check(QiblaMath.relative(350,10)==-20,"bearing cross north reverse");
    }
}
