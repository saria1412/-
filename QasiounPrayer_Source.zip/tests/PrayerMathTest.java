import com.sarf.qasioun.prayer.PrayerMath;
import java.time.*;
public class PrayerMathTest {
    private static void ok(boolean value, String name) { if (!value) throw new AssertionError(name); System.out.println("PASS " + name); }
    public static void main(String[] args) {
        LocalDate d = LocalDate.of(2026,10,9);
        long a=PrayerMath.epochMillis(d,"05:00 (+03)","Asia/Riyadh");
        ZonedDateTime time=Instant.ofEpochMilli(a).atZone(ZoneId.of("Asia/Riyadh"));
        ok(time.getHour()==5 && time.getDayOfMonth()==9,"Riyadh local prayer time");
        ok(PrayerMath.remainingMillis(a-300_000,a)==300_000,"countdown before prayer");
        ok(PrayerMath.remainingMillis(a+1,a)==0,"countdown clamps after prayer");
        ok(PrayerMath.distanceKm(21.54333,39.17278,21.54333,39.17278)<.001,"distance same place");
        ok(PrayerMath.distanceKm(21.54,39.17,24.71,46.67)>800,"distance Jeddah Riyadh");
        ok(PrayerMath.isFresh(10_000_000,11_000_000,1),"fresh data");
        ok(!PrayerMath.isFresh(10_000_000,20_000_000,1),"stale data");
        long dst = PrayerMath.epochMillis(LocalDate.of(2026,7,1),"13:15","Europe/London");
        ok(Instant.ofEpochMilli(dst).atZone(ZoneId.of("Europe/London")).getHour()==13,"timezone DST");
    }
}
